from django.apps import AppConfig


class MymodelsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mymodels'
